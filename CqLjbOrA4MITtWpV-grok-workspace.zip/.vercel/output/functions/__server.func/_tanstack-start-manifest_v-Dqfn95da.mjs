//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dqfn95da.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-B3kaZ5Mz.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B3kaZ5Mz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B95hj1h0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
