import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as CircleHelp, i as Heart, o as Check, r as Menu, t as X } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent, s as DialogTrigger, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D6iW_-a5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEMES = [
	{
		id: "black",
		label: "黑",
		swatch: "#1a1b20"
	},
	{
		id: "pink",
		label: "粉紅",
		swatch: "#ffc0cb"
	},
	{
		id: "sunset",
		label: "夕陽橙",
		swatch: "#f1b04c"
	},
	{
		id: "teal",
		label: "土耳其藍",
		swatch: "#40e0d0"
	}
];
var MOOD_LABEL = {
	boot: "開機中",
	idle: "放空",
	soothe: "療癒中",
	sleep: "睡著了",
	dizzy: "暈乎乎",
	faint: "昏倒了",
	cry: "嗚嗚",
	eat: "好好吃",
	startle: "嚇到了",
	angry: "生氣氣",
	curious: "那是什麼",
	happy: "驚喜"
};
var EYE_COLOR = {
	black: "#7ee8ea",
	pink: "#ff8fab",
	sunset: "#ffe0a3",
	teal: "#e8fffc"
};
var SHAKE_MOODS = [
	"dizzy",
	"faint",
	"cry"
];
var FOODS = [
	"lollipop",
	"burger",
	"sushi"
];
function pick(list) {
	return list[Math.floor(Math.random() * list.length)];
}
var ctx = null;
var unlocked = false;
function getCtx() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const AC = window.AudioContext || window.webkitAudioContext;
		if (!AC) return null;
		ctx = new AC();
	}
	return ctx;
}
function unlockAudio() {
	const c = getCtx();
	if (!c) return;
	if (c.state === "suspended") c.resume();
	unlocked = true;
}
function playOne(c, chirp, at) {
	const osc = c.createOscillator();
	const gain = c.createGain();
	osc.type = chirp.type ?? "sine";
	osc.frequency.setValueAtTime(chirp.freq, at);
	if (chirp.slide) osc.frequency.exponentialRampToValueAtTime(Math.max(40, chirp.freq * chirp.slide), at + chirp.dur);
	const g = chirp.gain ?? .07;
	gain.gain.setValueAtTime(1e-4, at);
	gain.gain.exponentialRampToValueAtTime(g, at + .018);
	gain.gain.exponentialRampToValueAtTime(1e-4, at + chirp.dur);
	osc.connect(gain);
	gain.connect(c.destination);
	osc.start(at);
	osc.stop(at + chirp.dur + .02);
}
function play(notes) {
	const c = getCtx();
	if (!c || !unlocked) return;
	if (c.state === "suspended") c.resume();
	const t0 = c.currentTime;
	for (const n of notes) playOne(c, n, t0 + (n.delay ?? 0));
}
var petSfx = {
	boot: () => play([
		{
			freq: 440,
			dur: .09,
			delay: 0
		},
		{
			freq: 660,
			dur: .12,
			delay: .1
		},
		{
			freq: 880,
			dur: .16,
			delay: .22,
			slide: 1.1
		}
	]),
	soothe: () => play([
		{
			freq: 523,
			dur: .14,
			gain: .05
		},
		{
			freq: 659,
			dur: .18,
			delay: .12,
			gain: .05
		},
		{
			freq: 784,
			dur: .22,
			delay: .26,
			gain: .04
		}
	]),
	startle: () => play([{
		freq: 980,
		dur: .08,
		type: "square",
		gain: .04,
		slide: 1.4
	}]),
	angry: () => play([{
		freq: 140,
		dur: .16,
		type: "sawtooth",
		gain: .04
	}, {
		freq: 110,
		dur: .2,
		type: "sawtooth",
		gain: .04,
		delay: .14
	}]),
	eat: () => play([
		{
			freq: 180,
			dur: .07,
			type: "triangle",
			gain: .06
		},
		{
			freq: 160,
			dur: .07,
			type: "triangle",
			gain: .05,
			delay: .12
		},
		{
			freq: 200,
			dur: .08,
			type: "triangle",
			gain: .05,
			delay: .24
		}
	]),
	happy: () => play([
		{
			freq: 523,
			dur: .1
		},
		{
			freq: 659,
			dur: .1,
			delay: .1
		},
		{
			freq: 784,
			dur: .12,
			delay: .2
		},
		{
			freq: 1046,
			dur: .18,
			delay: .32,
			gain: .05
		}
	]),
	cry: () => play([{
		freq: 420,
		dur: .22,
		slide: .7,
		gain: .05
	}, {
		freq: 360,
		dur: .28,
		slide: .65,
		gain: .04,
		delay: .24
	}]),
	dizzy: () => play([{
		freq: 500,
		dur: .18,
		slide: .6,
		type: "triangle",
		gain: .05
	}, {
		freq: 700,
		dur: .18,
		slide: .55,
		type: "triangle",
		gain: .04,
		delay: .16
	}]),
	faint: () => play([{
		freq: 240,
		dur: .4,
		slide: .4,
		type: "sine",
		gain: .05
	}]),
	curious: () => play([{
		freq: 480,
		dur: .16,
		slide: 1.6,
		gain: .045
	}]),
	sleep: () => play([{
		freq: 220,
		dur: .35,
		slide: .7,
		gain: .03
	}])
};
function playMoodSfx(mood) {
	({
		soothe: petSfx.soothe,
		startle: petSfx.startle,
		angry: petSfx.angry,
		eat: petSfx.eat,
		happy: petSfx.happy,
		cry: petSfx.cry,
		dizzy: petSfx.dizzy,
		faint: petSfx.faint,
		curious: petSfx.curious,
		sleep: petSfx.sleep,
		boot: petSfx.boot
	})[mood]?.();
}
var STORAGE_KEY = "nubo-settings-v1";
function readSaved() {
	if (typeof window === "undefined") return {
		name: "robot",
		theme: "black"
	};
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return {
			name: "robot",
			theme: "black"
		};
		const parsed = JSON.parse(raw);
		return {
			name: typeof parsed.name === "string" && parsed.name.trim() ? parsed.name.trim().slice(0, 16) : "robot",
			theme: parsed.theme === "pink" || parsed.theme === "sunset" || parsed.theme === "teal" || parsed.theme === "black" ? parsed.theme : "black"
		};
	} catch {
		return {
			name: "robot",
			theme: "black"
		};
	}
}
function writeSaved(name, theme) {
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify({
			name,
			theme
		}));
	} catch {}
}
var usePetStore = create((set, get) => ({
	name: "robot",
	theme: "black",
	mood: "boot",
	food: null,
	pokeCount: 0,
	lookX: 0,
	lookY: 0,
	held: false,
	settingsOpen: false,
	helpOpen: false,
	animNonce: 0,
	hydrated: false,
	hydrate: () => {
		if (get().hydrated) return;
		const saved = readSaved();
		set({
			name: saved.name,
			theme: saved.theme,
			hydrated: true
		});
	},
	setName: (name) => {
		const next = name.trim() ? name.trim().slice(0, 16) : "robot";
		set({ name: next });
		writeSaved(next, get().theme);
	},
	setTheme: (theme) => {
		set({ theme });
		writeSaved(get().name, theme);
	},
	setMood: (mood) => set({ mood }),
	setFood: (food) => set({ food }),
	setPokeCount: (n) => set({ pokeCount: n }),
	setLook: (x, y) => set({
		lookX: x,
		lookY: y
	}),
	setHeld: (held) => set({ held }),
	setSettingsOpen: (open) => set({ settingsOpen: open }),
	setHelpOpen: (open) => set({ helpOpen: open }),
	bumpAnim: () => set({ animNonce: get().animNonce + 1 })
}));
var W = 128;
var H = 64;
function oval(ctx, cx, cy, rx, ry, color) {
	const rxn = Math.max(1, Math.round(rx));
	const ryn = Math.max(1, Math.round(ry));
	ctx.fillStyle = color;
	for (let y = -ryn; y <= ryn; y++) {
		const t = 1 - y * y / (ryn * ryn);
		if (t < 0) continue;
		const xw = Math.round(Math.sqrt(t) * rxn);
		ctx.fillRect(Math.round(cx) - xw, Math.round(cy) + y, xw * 2 + 1, 1);
	}
}
function stamp(ctx, x0, y0, x1, y1, x2, y2, w, color) {
	for (let i = 0; i <= 14; i++) {
		const t = i / 14;
		const u = 1 - t;
		oval(ctx, u * u * x0 + 2 * u * t * x1 + t * t * x2, u * u * y0 + 2 * u * t * y1 + t * t * y2, w, w * .85, color);
	}
}
function thickLine(ctx, x0, y0, x1, y1, r, color) {
	const dx = x1 - x0;
	const dy = y1 - y0;
	const n = Math.max(8, Math.round(Math.hypot(dx, dy)));
	for (let i = 0; i <= n; i++) {
		const t = i / n;
		oval(ctx, x0 + dx * t, y0 + dy * t, r, r, color);
	}
}
function spark(ctx, x, y, s, color) {
	thickLine(ctx, x - s, y, x + s, y, 1.1, color);
	thickLine(ctx, x, y - s, x, y + s, 1.1, color);
}
function PixelFace({ mood, lookX, lookY, eyeColor, blinking }) {
	const ref = (0, import_react.useRef)(null);
	const t0 = (0, import_react.useRef)(performance.now());
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		const loop = (now) => {
			const t = (now - t0.current) / 1e3;
			drawFace(ctx, {
				mood,
				lookX,
				lookY,
				eyeColor,
				blinking,
				t
			});
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [
		mood,
		lookX,
		lookY,
		eyeColor,
		blinking
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		width: W,
		height: H,
		className: "nubo-oled-canvas",
		"aria-hidden": "true"
	});
}
function drawFace(ctx, d) {
	ctx.fillStyle = "#07080a";
	ctx.fillRect(0, 0, W, H);
	const color = d.eyeColor;
	const dim = mix(color, "#07080a", .45);
	const lx = 44 + d.lookX * 10;
	const rx = 84 + d.lookX * 10;
	const ey = 30 + d.lookY * 7;
	if (d.mood === "boot") {
		const p = Math.min(1, d.t / .7);
		oval(ctx, 64, 32, 18 * p + 6, 1.6, color);
		if (p > .55) {
			const open = (p - .55) / .45;
			oval(ctx, lx, ey, 11, 2 + 10 * open, color);
			oval(ctx, rx, ey, 11, 2 + 10 * open, color);
		}
		return;
	}
	if (d.blinking && (d.mood === "idle" || d.mood === "curious" || d.mood === "soothe")) {
		oval(ctx, lx, ey, 12, 1.6, color);
		oval(ctx, rx, ey, 12, 1.6, color);
		return;
	}
	switch (d.mood) {
		case "idle":
			oval(ctx, lx, ey, 12, 11, color);
			oval(ctx, rx, ey, 12, 11, color);
			break;
		case "soothe":
			stamp(ctx, lx - 12, ey + 4, lx, ey - 8, lx + 12, ey + 4, 2.2, color);
			stamp(ctx, rx - 12, ey + 4, rx, ey - 8, rx + 12, ey + 4, 2.2, color);
			oval(ctx, 28, 42, 6, 3, "#ff8fab");
			oval(ctx, 100, 42, 6, 3, "#ff8fab");
			break;
		case "sleep": {
			const wiggle = Math.sin(d.t * 1.4) * .8;
			oval(ctx, lx, ey + 2 + wiggle, 13, 1.8, color);
			oval(ctx, rx, ey + 2 - wiggle, 13, 1.8, color);
			break;
		}
		case "dizzy": {
			const a = d.t * 6;
			oval(ctx, lx + Math.cos(a) * 3, ey + Math.sin(a) * 2, 11, 11, color);
			oval(ctx, lx + Math.cos(a + 1.2) * 4, ey + Math.sin(a + 1.2) * 3, 4, 4, dim);
			oval(ctx, rx + Math.cos(a + .7) * 3, ey + Math.sin(a + .7) * 2, 11, 11, color);
			oval(ctx, rx + Math.cos(a + 2) * 4, ey + Math.sin(a + 2) * 3, 4, 4, dim);
			spark(ctx, 18, 16, 4 + Math.sin(d.t * 8), color);
			spark(ctx, 110, 18, 3 + Math.cos(d.t * 7), color);
			break;
		}
		case "faint":
			thickLine(ctx, lx - 9, ey - 8, lx + 9, ey + 8, 2.2, color);
			thickLine(ctx, lx + 9, ey - 8, lx - 9, ey + 8, 2.2, color);
			thickLine(ctx, rx - 9, ey - 8, rx + 9, ey + 8, 2.2, color);
			thickLine(ctx, rx + 9, ey - 8, rx - 9, ey + 8, 2.2, color);
			oval(ctx, 64, 50, 7, 3, color);
			break;
		case "cry": {
			oval(ctx, lx, ey, 10, 12, color);
			oval(ctx, rx, ey, 10, 12, color);
			oval(ctx, lx, ey - 2, 3, 3, "#07080a");
			oval(ctx, rx, ey - 2, 3, 3, "#07080a");
			stamp(ctx, 54, 46, 64, 54, 74, 46, 1.6, color);
			const drop = d.t * 28 % 22 + 38;
			oval(ctx, lx, drop, 2.2, 3.4, color);
			oval(ctx, rx, drop + 4, 2.2, 3.4, color);
			break;
		}
		case "eat": {
			stamp(ctx, lx - 11, ey + 3, lx, ey - 7, lx + 11, ey + 3, 2.1, color);
			stamp(ctx, rx - 11, ey + 3, rx, ey - 7, rx + 11, ey + 3, 2.1, color);
			const chew = 5 + Math.abs(Math.sin(d.t * 10)) * 5;
			oval(ctx, 64, 48, 9, chew, color);
			oval(ctx, 64, 48, 5, Math.max(1, chew - 3), "#07080a");
			break;
		}
		case "startle":
			oval(ctx, lx, ey, 15, 15, color);
			oval(ctx, rx, ey, 15, 15, color);
			oval(ctx, lx + d.lookX * 3, ey + d.lookY * 3, 4, 5, "#07080a");
			oval(ctx, rx + d.lookX * 3, ey + d.lookY * 3, 4, 5, "#07080a");
			break;
		case "angry":
			thickLine(ctx, lx - 12, ey - 8, lx + 11, ey - 1, 2.4, color);
			thickLine(ctx, rx + 12, ey - 8, rx - 11, ey - 1, 2.4, color);
			oval(ctx, lx, ey + 5, 9, 7, color);
			oval(ctx, rx, ey + 5, 9, 7, color);
			oval(ctx, lx, ey + 6, 3, 3, "#07080a");
			oval(ctx, rx, ey + 6, 3, 3, "#07080a");
			thickLine(ctx, 54, 50, 74, 50, 1.6, color);
			break;
		case "curious":
			oval(ctx, lx, ey, 9, 13, color);
			oval(ctx, rx, ey, 13, 10, color);
			oval(ctx, lx + d.lookX * 3, ey + d.lookY * 4, 3, 4, "#07080a");
			oval(ctx, rx + d.lookX * 4, ey + d.lookY * 3, 3.5, 3.5, "#07080a");
			break;
		case "happy":
			stamp(ctx, lx - 13, ey + 5, lx, ey - 10, lx + 13, ey + 5, 2.4, color);
			stamp(ctx, rx - 13, ey + 5, rx, ey - 10, rx + 13, ey + 5, 2.4, color);
			stamp(ctx, 52, 46, 64, 56, 76, 46, 1.8, color);
			spark(ctx, 16, 14, 5 + Math.sin(d.t * 8), color);
			spark(ctx, 112, 18, 4 + Math.cos(d.t * 6), color);
			oval(ctx, 26, 42, 6, 3, "#ff8fab");
			oval(ctx, 102, 42, 6, 3, "#ff8fab");
			break;
		default:
			oval(ctx, lx, ey, 12, 11, color);
			oval(ctx, rx, ey, 12, 11, color);
	}
}
function mix(hex, other, t) {
	const a = parseHex(hex);
	const b = parseHex(other);
	const m = (i) => Math.round(a[i] * (1 - t) + b[i] * t);
	return `rgb(${m(0)} ${m(1)} ${m(2)})`;
}
function parseHex(hex) {
	const h = hex.replace("#", "");
	if (h.length !== 6) return [
		126,
		232,
		234
	];
	return [
		Number.parseInt(h.slice(0, 2), 16),
		Number.parseInt(h.slice(2, 4), 16),
		Number.parseInt(h.slice(4, 6), 16)
	];
}
function FoodProp({ kind }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "nubo-food",
		"data-kind": kind,
		"aria-hidden": "true",
		children: kind === "lollipop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lollipop, {}) : kind === "burger" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Burger, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sushi, {})
	});
}
function Lollipop() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 96",
		className: "nubo-food-svg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "30",
				y: "40",
				width: "5",
				height: "48",
				rx: "2",
				fill: "#e8d5b0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "28",
				r: "22",
				fill: "#ff6b8a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M32 10c10 0 18 8 18 18 0 4-1 7-3 10",
				fill: "none",
				stroke: "#ffe3ea",
				strokeWidth: "5",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "24",
				cy: "20",
				r: "5",
				fill: "rgba(255,255,255,0.45)"
			})
		]
	});
}
function Burger() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 72 64",
		className: "nubo-food-svg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "36",
				cy: "18",
				rx: "28",
				ry: "12",
				fill: "#e2a054"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "8",
				y: "18",
				width: "56",
				height: "8",
				fill: "#e2a054"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "26",
				width: "52",
				height: "6",
				rx: "2",
				fill: "#6dbd5b"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "9",
				y: "32",
				width: "54",
				height: "10",
				rx: "3",
				fill: "#7a3e24"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "11",
				y: "42",
				width: "50",
				height: "6",
				rx: "2",
				fill: "#f1d36b"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "36",
				cy: "52",
				rx: "28",
				ry: "9",
				fill: "#c9843a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "16",
				r: "2.2",
				fill: "#f4f0e6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "40",
				cy: "14",
				r: "1.8",
				fill: "#f4f0e6"
			})
		]
	});
}
function Sushi() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 80 48",
		className: "nubo-food-svg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "28",
				rx: "32",
				ry: "14",
				fill: "#1c1c20"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "24",
				rx: "28",
				ry: "11",
				fill: "#f4efe6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "40",
				cy: "18",
				rx: "26",
				ry: "9",
				fill: "#e07070"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M18 18c8 4 36 4 44 0",
				fill: "none",
				stroke: "#f4efe6",
				strokeWidth: "2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "36",
				y: "8",
				width: "8",
				height: "28",
				fill: "#1c1c20"
			})
		]
	});
}
function Robot({ blinking, hold, onZonePointerDown }) {
	const mood = usePetStore((s) => s.mood);
	const name = usePetStore((s) => s.name);
	const theme = usePetStore((s) => s.theme);
	const lookX = usePetStore((s) => s.lookX);
	const lookY = usePetStore((s) => s.lookY);
	const food = usePetStore((s) => s.food);
	const held = usePetStore((s) => s.held);
	const animNonce = usePetStore((s) => s.animNonce);
	const style = hold ? {
		transform: `translate(${hold.x}px, ${hold.y}px) rotate(${hold.rot}deg)`,
		transition: "none"
	} : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nubo-stage",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "nubo-shadow",
				"data-held": held ? "1" : "0",
				"data-mood": mood,
				style: hold ? { transform: `translateX(${hold.x * .4}px) scale(${.72 + Math.min(.2, Math.abs(hold.y) / 400)})` } : void 0
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nubo-robot",
				"data-mood": mood,
				"data-held": held ? "1" : "0",
				"data-nonce": animNonce,
				style,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arm, {
						side: "left",
						mood
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arm, {
						side: "right",
						mood
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "nubo-torso",
						"data-zone": "body",
						"aria-label": "點身體",
						onPointerDown: (e) => onZonePointerDown("body", e),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nubo-belly" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nubo-plate",
							children: name || "robot"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "nubo-head",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "nubo-cap",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "nubo-head-hit",
								"data-zone": "head",
								"aria-label": "摸頭",
								onPointerDown: (e) => onZonePointerDown("head", e)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "nubo-forehead",
								"data-zone": "forehead",
								"aria-label": "連點額頭",
								onPointerDown: (e) => onZonePointerDown("forehead", e)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "nubo-oled",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PixelFace, {
									mood,
									lookX,
									lookY,
									eyeColor: EYE_COLOR[theme],
									blinking
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "nubo-mouth",
								"data-zone": "mouth",
								"aria-label": "點嘴巴",
								onPointerDown: (e) => onZonePointerDown("mouth", e)
							}),
							food ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoodProp, { kind: food }) : null
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "nubo-mood-label",
				children: MOOD_LABEL[mood]
			})
		]
	});
}
function Arm({ side, mood }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "nubo-arm",
		"data-side": side,
		"data-mood": mood,
		"aria-hidden": "true"
	});
}
function SettingsSheet({ motionReady, onEnableMotion }) {
	const open = usePetStore((s) => s.settingsOpen);
	const setOpen = usePetStore((s) => s.setSettingsOpen);
	const name = usePetStore((s) => s.name);
	const setName = usePetStore((s) => s.setName);
	const theme = usePetStore((s) => s.theme);
	const setTheme = usePetStore((s) => s.setTheme);
	const [draft, setDraft] = (0, import_react.useState)(name);
	(0, import_react.useEffect)(() => {
		if (open) setDraft(name);
	}, [open, name]);
	function commitName() {
		setName(draft.trim() ? draft : "robot");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "nubo-icon-btn",
				"aria-label": "開啟設定",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
					size: 22,
					strokeWidth: 2
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "nubo-overlay" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "nubo-sheet",
			"aria-describedby": void 0,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nubo-sheet-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "nubo-sheet-title",
						children: "設定"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "nubo-icon-btn nubo-icon-btn-ghost",
							"aria-label": "關閉設定",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
								size: 20,
								strokeWidth: 2
							})
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "nubo-field",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nubo-field-label",
							children: "姓名"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "nubo-input",
							value: draft,
							maxLength: 16,
							placeholder: "robot",
							onChange: (e) => setDraft(e.target.value),
							onBlur: commitName,
							onKeyDown: (e) => {
								if (e.key === "Enter") {
									commitName();
									e.target.blur();
								}
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "nubo-field-hint",
							children: "沒填的話會叫 robot"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "nubo-field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "nubo-field-label",
						children: "色系"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nubo-swatches",
						children: THEMES.map((item) => {
							const selected = theme === item.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "nubo-swatch",
								"data-selected": selected ? "1" : "0",
								"data-theme-id": item.id,
								onClick: () => setTheme(item.id),
								"aria-pressed": selected,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nubo-swatch-dot" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "nubo-swatch-name",
										children: item.label
									}),
									selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
										size: 16,
										strokeWidth: 2.4
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "nubo-swatch-spacer" })
								]
							}, item.id);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nubo-field",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nubo-field-label",
						children: "搖晃感應"
					}), motionReady ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "nubo-field-hint",
						children: "已開啟。搖晃手機會讓他暈眩、昏倒或哭哭。"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nubo-btn",
						onClick: onEnableMotion,
						children: "允許搖晃感應"
					})]
				})
			]
		})] })]
	});
}
function FxLayer({ particles, mood }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nubo-fx",
		"aria-hidden": "true",
		children: [particles.map((p) => {
			const t = 1 - p.life / p.max;
			const style = {
				left: `${p.x}px`,
				top: `${p.y}px`,
				opacity: t,
				transform: `translate(-50%, -50%) scale(${.7 + t * .5})`
			};
			if (p.kind === "heart") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nubo-part nubo-part-heart",
				style,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
					size: 18,
					fill: "currentColor",
					strokeWidth: 0
				})
			}, p.id);
			if (p.kind === "zzz") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nubo-part nubo-part-z",
				style,
				children: "z"
			}, p.id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "nubo-part nubo-part-spark",
				style,
				children: "+"
			}, p.id);
		}), mood === "sleep" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "nubo-snore",
			children: "z"
		}) : null]
	});
}
var SLEEP_AFTER_MS = 3e4;
var SOOTHE_HOLD_MS = 5e3;
var SHAKE_COOLDOWN = 1600;
var HELP = [
	{
		title: "摸頭",
		text: "療癒表情，30 秒後會睡著"
	},
	{
		title: "抓起 / 搖晃",
		text: "暈眩、昏倒、哭哭，隨機一種"
	},
	{
		title: "點嘴巴",
		text: "吃棒棒糖、漢堡或壽司"
	},
	{
		title: "點身體",
		text: "驚嚇，點滿十次會生氣氣"
	},
	{
		title: "點畫面",
		text: "好奇地看向你點的地方"
	},
	{
		title: "連點額頭兩下",
		text: "驚喜、開心"
	}
];
function PetScene() {
	const mood = usePetStore((s) => s.mood);
	const name = usePetStore((s) => s.name);
	const theme = usePetStore((s) => s.theme);
	const pokeCount = usePetStore((s) => s.pokeCount);
	const held = usePetStore((s) => s.held);
	const helpOpen = usePetStore((s) => s.helpOpen);
	const settingsOpen = usePetStore((s) => s.settingsOpen);
	const hydrate = usePetStore((s) => s.hydrate);
	const setMood = usePetStore((s) => s.setMood);
	const setFood = usePetStore((s) => s.setFood);
	const setPokeCount = usePetStore((s) => s.setPokeCount);
	const setLook = usePetStore((s) => s.setLook);
	const setHeld = usePetStore((s) => s.setHeld);
	const setHelpOpen = usePetStore((s) => s.setHelpOpen);
	const bumpAnim = usePetStore((s) => s.bumpAnim);
	const [blinking, setBlinking] = (0, import_react.useState)(false);
	const [motionReady, setMotionReady] = (0, import_react.useState)(false);
	const [hold, setHold] = (0, import_react.useState)(null);
	const [particles, setParticles] = (0, import_react.useState)([]);
	const sceneRef = (0, import_react.useRef)(null);
	const timers = (0, import_react.useRef)({});
	const pokeRef = (0, import_react.useRef)(0);
	const lastShake = (0, import_react.useRef)(0);
	const lastForehead = (0, import_react.useRef)(0);
	const drag = (0, import_react.useRef)(null);
	const accPrev = (0, import_react.useRef)(null);
	const lookTarget = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const lookNow = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const publishedLook = (0, import_react.useRef)({
		x: 0,
		y: 0
	});
	const partId = (0, import_react.useRef)(1);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const buzz = (pattern) => {
		try {
			navigator.vibrate?.(pattern);
		} catch {}
	};
	const spawn = (0, import_react.useCallback)((kind, n, origin) => {
		const rect = (sceneRef.current?.querySelector(".nubo-head"))?.getBoundingClientRect();
		const scene = sceneRef.current?.getBoundingClientRect();
		const ox = origin?.x ?? (rect && scene ? rect.left - scene.left + rect.width * .5 : 180);
		const oy = origin?.y ?? (rect && scene ? rect.top - scene.top + rect.height * .2 : 180);
		setParticles((prev) => {
			const next = [...prev];
			for (let i = 0; i < n; i++) next.push({
				id: partId.current++,
				x: ox + (Math.random() - .5) * 40,
				y: oy + (Math.random() - .5) * 16,
				vx: (Math.random() - .5) * 40,
				vy: -30 - Math.random() * 50,
				life: .9 + Math.random() * .5,
				max: .9 + Math.random() * .5,
				kind
			});
			return next.slice(-28);
		});
	}, []);
	const goMood = (0, import_react.useCallback)((next, holdMs) => {
		window.clearTimeout(timers.current.mood);
		setMood(next);
		bumpAnim();
		playMoodSfx(next);
		if (next === "soothe") spawn("heart", 5);
		if (next === "happy") spawn("spark", 6);
		if (next === "sleep") spawn("zzz", 3);
		if (holdMs && next !== "sleep" && next !== "angry") timers.current.mood = window.setTimeout(() => {
			const angry = pokeRef.current >= 10;
			setMood(angry ? "angry" : "idle");
			setFood(null);
		}, holdMs);
	}, [
		bumpAnim,
		setFood,
		setMood,
		spawn
	]);
	const scheduleSleep = (0, import_react.useCallback)(() => {
		window.clearTimeout(timers.current.sleep);
		timers.current.sleep = window.setTimeout(() => {
			goMood("sleep");
			buzz(12);
		}, SLEEP_AFTER_MS);
	}, [goMood]);
	const interruptSleepTimer = () => {
		window.clearTimeout(timers.current.sleep);
	};
	(0, import_react.useEffect)(() => {
		pokeRef.current = pokeCount;
	}, [pokeCount]);
	(0, import_react.useEffect)(() => {
		const boot = window.setTimeout(() => {
			unlockAudio();
			playMoodSfx("boot");
			setMood("idle");
		}, 900);
		return () => window.clearTimeout(boot);
	}, [setMood]);
	(0, import_react.useEffect)(() => {
		let raf = 0;
		let last = performance.now();
		const loop = (now) => {
			const dt = Math.min(.1, (now - last) / 1e3);
			last = now;
			lookNow.current.x += (lookTarget.current.x - lookNow.current.x) * (1 - Math.exp(-8 * dt));
			lookNow.current.y += (lookTarget.current.y - lookNow.current.y) * (1 - Math.exp(-8 * dt));
			if (Math.abs(lookNow.current.x - publishedLook.current.x) > .02 || Math.abs(lookNow.current.y - publishedLook.current.y) > .02) {
				publishedLook.current = { ...lookNow.current };
				setLook(lookNow.current.x, lookNow.current.y);
			}
			setParticles((prev) => {
				if (prev.length === 0) return prev;
				return prev.map((p) => ({
					...p,
					x: p.x + p.vx * dt,
					y: p.y + p.vy * dt,
					vy: p.vy + 40 * dt,
					life: p.life - dt
				})).filter((p) => p.life > 0);
			});
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(raf);
	}, [setLook]);
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const m = usePetStore.getState().mood;
			if (m === "idle" || m === "soothe" || m === "curious") {
				setBlinking(true);
				window.setTimeout(() => setBlinking(false), 140);
			}
			timers.current.blink = window.setTimeout(tick, 2800 + Math.random() * 2600);
		};
		timers.current.blink = window.setTimeout(tick, 1800);
		return () => window.clearTimeout(timers.current.blink);
	}, []);
	(0, import_react.useEffect)(() => {
		const wander = () => {
			if (usePetStore.getState().mood === "idle" && !usePetStore.getState().held) lookTarget.current = {
				x: (Math.random() - .5) * 1.2,
				y: (Math.random() - .5) * .8
			};
		};
		const id = window.setInterval(wander, 3200);
		return () => window.clearInterval(id);
	}, []);
	const lookAtPoint = (clientX, clientY) => {
		const face = sceneRef.current?.querySelector(".nubo-oled");
		if (!face) return;
		const r = face.getBoundingClientRect();
		const cx = r.left + r.width / 2;
		const cy = r.top + r.height / 2;
		const nx = Math.max(-1, Math.min(1, (clientX - cx) / (window.innerWidth * .35)));
		const ny = Math.max(-1, Math.min(1, (clientY - cy) / (window.innerHeight * .35)));
		lookTarget.current = {
			x: nx,
			y: ny
		};
	};
	const applyShake = (0, import_react.useCallback)(() => {
		const now = performance.now();
		if (now - lastShake.current < SHAKE_COOLDOWN) return;
		lastShake.current = now;
		interruptSleepTimer();
		const next = pick(SHAKE_MOODS);
		setFood(null);
		goMood(next, 3200);
		buzz([
			18,
			40,
			30
		]);
		setHeld(false);
		setHold(null);
	}, [
		goMood,
		setFood,
		setHeld
	]);
	const onMotion = (0, import_react.useCallback)((e) => {
		const acc = e.accelerationIncludingGravity;
		if (!acc) return;
		const t = performance.now();
		const cur = {
			x: acc.x ?? 0,
			y: acc.y ?? 0,
			z: acc.z ?? 0,
			t
		};
		const prev = accPrev.current;
		accPrev.current = cur;
		if (!prev || t - prev.t < 50) return;
		if (Math.abs(cur.x - prev.x) + Math.abs(cur.y - prev.y) + Math.abs(cur.z - prev.z) > 22) applyShake();
	}, [applyShake]);
	const enableMotion = (0, import_react.useCallback)(async () => {
		try {
			const DM = window.DeviceMotionEvent;
			if (typeof DM.requestPermission === "function") {
				if (await DM.requestPermission() !== "granted") return;
			}
			window.removeEventListener("devicemotion", onMotion);
			window.addEventListener("devicemotion", onMotion);
			setMotionReady(true);
		} catch {
			window.removeEventListener("devicemotion", onMotion);
			window.addEventListener("devicemotion", onMotion);
			setMotionReady(true);
		}
	}, [onMotion]);
	(0, import_react.useEffect)(() => {
		return () => {
			window.removeEventListener("devicemotion", onMotion);
			window.clearTimeout(timers.current.mood);
			window.clearTimeout(timers.current.sleep);
			window.clearTimeout(timers.current.blink);
		};
	}, [onMotion]);
	const petHead = () => {
		interruptSleepTimer();
		setPokeCount(0);
		pokeRef.current = 0;
		setFood(null);
		goMood("soothe", SOOTHE_HOLD_MS);
		scheduleSleep();
		buzz(12);
	};
	const pokeBody = () => {
		interruptSleepTimer();
		const n = pokeRef.current + 1;
		pokeRef.current = n;
		setPokeCount(n);
		setFood(null);
		if (n >= 10) {
			goMood("angry");
			buzz([
				30,
				40,
				40,
				40,
				50
			]);
		} else {
			goMood("startle", 1100);
			buzz(24);
		}
	};
	const eatMouth = () => {
		interruptSleepTimer();
		const food = pick(FOODS);
		setFood(food);
		goMood("eat", 2800);
		buzz(10);
	};
	const happyForehead = () => {
		interruptSleepTimer();
		setFood(null);
		goMood("happy", 2600);
		buzz([
			10,
			20,
			10
		]);
	};
	const curiousAt = (x, y) => {
		interruptSleepTimer();
		lookAtPoint(x, y);
		setFood(null);
		goMood("curious", 1800);
	};
	const handleTap = (zone, x, y) => {
		if (zone === "scene") {
			curiousAt(x, y);
			return;
		}
		if (zone === "mouth") {
			eatMouth();
			return;
		}
		if (zone === "body") {
			pokeBody();
			return;
		}
		if (zone === "forehead") {
			const now = performance.now();
			if (now - lastForehead.current < 420) {
				lastForehead.current = 0;
				happyForehead();
				return;
			}
			lastForehead.current = now;
			petHead();
			return;
		}
		petHead();
	};
	const onZonePointerDown = (zone, e) => {
		e.stopPropagation();
		e.preventDefault();
		unlockAudio();
		enableMotion();
		e.currentTarget.setPointerCapture?.(e.pointerId);
		drag.current = {
			active: true,
			pointerId: e.pointerId,
			zone,
			sx: e.clientX,
			sy: e.clientY,
			x: e.clientX,
			y: e.clientY,
			moved: false,
			samples: [{
				t: performance.now(),
				x: e.clientX,
				y: e.clientY
			}]
		};
	};
	const onScenePointerDown = (e) => {
		if (e.target.closest("[data-zone]")) return;
		if (e.target.closest("button, input, [role='dialog']")) return;
		unlockAudio();
		enableMotion();
		drag.current = {
			active: true,
			pointerId: e.pointerId,
			zone: "scene",
			sx: e.clientX,
			sy: e.clientY,
			x: e.clientX,
			y: e.clientY,
			moved: false,
			samples: []
		};
	};
	const onPointerMove = (e) => {
		const d = drag.current;
		if (!d || !d.active || d.pointerId !== e.pointerId) return;
		d.x = e.clientX;
		d.y = e.clientY;
		const dist = Math.hypot(d.x - d.sx, d.y - d.sy);
		const lift = d.sy - d.y;
		if (d.zone !== "scene" && (lift > 42 || dist > 64)) {
			d.moved = true;
			if (!held) setHeld(true);
			const dx = d.x - d.sx;
			const dy = d.y - d.sy;
			setHold({
				x: dx,
				y: dy,
				rot: Math.max(-18, Math.min(18, dx * .08))
			});
			const now = performance.now();
			d.samples.push({
				t: now,
				x: d.x,
				y: d.y
			});
			if (d.samples.length > 12) d.samples.shift();
			const recent = d.samples.filter((s) => now - s.t < 320);
			if (recent.length >= 6) {
				let flips = 0;
				for (let i = 2; i < recent.length; i++) {
					const a = recent[i];
					const b = recent[i - 1];
					const c = recent[i - 2];
					const v1x = b.x - c.x;
					const v2x = a.x - b.x;
					if (v1x * v2x < 0 && Math.abs(v1x) + Math.abs(v2x) > 18) flips += 1;
				}
				const travel = recent.reduce((sum, p, i) => {
					if (i === 0) return 0;
					return sum + Math.hypot(p.x - recent[i - 1].x, p.y - recent[i - 1].y);
				}, 0);
				if (flips >= 3 || travel > 280) {
					drag.current = null;
					applyShake();
				}
			}
		}
		if (d.zone === "scene") lookAtPoint(e.clientX, e.clientY);
	};
	const onPointerUp = (e) => {
		const d = drag.current;
		if (!d || d.pointerId !== e.pointerId) return;
		const moved = d.moved;
		const zone = d.zone;
		const x = e.clientX;
		const y = e.clientY;
		const lift = d.sy - d.y;
		drag.current = null;
		if (held || moved) {
			setHeld(false);
			setHold(null);
			if (lift > 48 || moved) applyShake();
			return;
		}
		handleTap(zone, x, y);
	};
	const onPointerCancel = () => {
		drag.current = null;
		setHeld(false);
		setHold(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "nubo-app",
		"data-theme": theme,
		"data-mood": mood,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: sceneRef,
				className: "nubo-scene",
				onPointerDown: onScenePointerDown,
				onPointerMove,
				onPointerUp,
				onPointerCancel,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nubo-glow" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "nubo-desk" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FxLayer, {
						particles,
						mood
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Robot, {
						blinking,
						hold,
						onZonePointerDown
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "nubo-top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nubo-brand",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nubo-brand-kicker",
						children: "Desk pal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "nubo-brand-name",
						children: name
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nubo-top-actions",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nubo-icon-btn",
						"aria-label": "玩法",
						onClick: () => setHelpOpen(!helpOpen),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
							size: 20,
							strokeWidth: 2
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsSheet, {
						motionReady,
						onEnableMotion: () => void enableMotion()
					})]
				})]
			}),
			helpOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "nubo-help",
				"aria-label": "玩法",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "nubo-help-head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "怎麼跟他玩" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "nubo-icon-btn nubo-icon-btn-ghost",
						"aria-label": "關閉玩法",
						onClick: () => setHelpOpen(false),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: HELP.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.text })] }, item.title)) })]
			}) : null,
			settingsOpen ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "nubo-hint",
				children: "摸頭 · 點嘴巴 · 點身體 · 點畫面 · 搖一搖"
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PetScene, {});
}
//#endregion
export { Home as component };
