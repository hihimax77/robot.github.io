import { useCallback, useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { HelpCircle, X } from "lucide-react";
import {
  FOODS,
  SHAKE_MOODS,
  type HitZone,
  type Mood,
  pick,
} from "@/lib/pet-types";
import { playMoodSfx, unlockAudio } from "@/lib/pet-audio";
import { usePetStore } from "@/lib/pet-store";
import { Robot } from "./robot";
import { SettingsSheet } from "./settings-sheet";
import { FxLayer, type Particle } from "./fx-layer";

const SLEEP_AFTER_MS = 30_000;
const SOOTHE_HOLD_MS = 5_000;
const SHAKE_COOLDOWN = 1600;

type Hold = { x: number; y: number; rot: number };

const HELP = [
  { title: "摸頭", text: "療癒表情，30 秒後會睡著" },
  { title: "抓起 / 搖晃", text: "暈眩、昏倒、哭哭，隨機一種" },
  { title: "點嘴巴", text: "吃棒棒糖、漢堡或壽司" },
  { title: "點身體", text: "驚嚇，點滿十次會生氣氣" },
  { title: "點畫面", text: "好奇地看向你點的地方" },
  { title: "連點額頭兩下", text: "驚喜、開心" },
];

export function PetScene() {
  const mood = usePetStore((s) => s.mood);
  const name = usePetStore((s) => s.name);
  const theme = usePetStore((s) => s.theme);
  const pokeCount = usePetStore((s) => s.pokeCount);
  const held = usePetStore((s) => s.held);
  const helpOpen = usePetStore((s) => s.helpOpen);
  const settingsOpen = usePetStore((s) => s.settingsOpen);
  const hydrate = usePetStore((s) => s.hydrate);
  const setMood = usePetStore((s) => s.setMood);
  const setFood = usePetStore((s) => s.setFood);
  const setPokeCount = usePetStore((s) => s.setPokeCount);
  const setLook = usePetStore((s) => s.setLook);
  const setHeld = usePetStore((s) => s.setHeld);
  const setHelpOpen = usePetStore((s) => s.setHelpOpen);
  const bumpAnim = usePetStore((s) => s.bumpAnim);

  const [blinking, setBlinking] = useState(false);
  const [motionReady, setMotionReady] = useState(false);
  const [hold, setHold] = useState<Hold | null>(null);
  const [particles, setParticles] = useState<Particle[]>([]);

  const sceneRef = useRef<HTMLDivElement>(null);
  const timers = useRef<{ mood?: number; sleep?: number; blink?: number }>({});
  const pokeRef = useRef(0);
  const lastShake = useRef(0);
  const lastForehead = useRef(0);
  const drag = useRef<{
    active: boolean;
    pointerId: number;
    zone: HitZone;
    sx: number;
    sy: number;
    x: number;
    y: number;
    moved: boolean;
    samples: { t: number; x: number; y: number }[];
  } | null>(null);
  const accPrev = useRef<{ x: number; y: number; z: number; t: number } | null>(
    null,
  );
  const lookTarget = useRef({ x: 0, y: 0 });
  const lookNow = useRef({ x: 0, y: 0 });
  const publishedLook = useRef({ x: 0, y: 0 });
  const partId = useRef(1);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const buzz = (pattern: number | number[]) => {
    try {
      navigator.vibrate?.(pattern);
    } catch {
      /* unsupported */
    }
  };

  const spawn = useCallback((kind: Particle["kind"], n: number, origin?: { x: number; y: number }) => {
    const host = sceneRef.current?.querySelector(".nubo-head") as HTMLElement | null;
    const rect = host?.getBoundingClientRect();
    const scene = sceneRef.current?.getBoundingClientRect();
    const ox =
      origin?.x ??
      (rect && scene ? rect.left - scene.left + rect.width * 0.5 : 180);
    const oy =
      origin?.y ??
      (rect && scene ? rect.top - scene.top + rect.height * 0.2 : 180);
    setParticles((prev) => {
      const next = [...prev];
      for (let i = 0; i < n; i++) {
        next.push({
          id: partId.current++,
          x: ox + (Math.random() - 0.5) * 40,
          y: oy + (Math.random() - 0.5) * 16,
          vx: (Math.random() - 0.5) * 40,
          vy: -30 - Math.random() * 50,
          life: 0.9 + Math.random() * 0.5,
          max: 0.9 + Math.random() * 0.5,
          kind,
        });
      }
      return next.slice(-28);
    });
  }, []);

  const goMood = useCallback(
    (next: Mood, holdMs?: number) => {
      window.clearTimeout(timers.current.mood);
      setMood(next);
      bumpAnim();
      playMoodSfx(next);
      if (next === "soothe") spawn("heart", 5);
      if (next === "happy") spawn("spark", 6);
      if (next === "sleep") spawn("zzz", 3);
      if (holdMs && next !== "sleep" && next !== "angry") {
        timers.current.mood = window.setTimeout(() => {
          const angry = pokeRef.current >= 10;
          setMood(angry ? "angry" : "idle");
          setFood(null);
        }, holdMs);
      }
    },
    [bumpAnim, setFood, setMood, spawn],
  );

  const scheduleSleep = useCallback(() => {
    window.clearTimeout(timers.current.sleep);
    timers.current.sleep = window.setTimeout(() => {
      goMood("sleep");
      buzz(12);
    }, SLEEP_AFTER_MS);
  }, [goMood]);

  const interruptSleepTimer = () => {
    window.clearTimeout(timers.current.sleep);
  };

  useEffect(() => {
    pokeRef.current = pokeCount;
  }, [pokeCount]);

  useEffect(() => {
    const boot = window.setTimeout(() => {
      unlockAudio();
      playMoodSfx("boot");
      setMood("idle");
    }, 900);
    return () => window.clearTimeout(boot);
  }, [setMood]);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      lookNow.current.x +=
        (lookTarget.current.x - lookNow.current.x) * (1 - Math.exp(-8 * dt));
      lookNow.current.y +=
        (lookTarget.current.y - lookNow.current.y) * (1 - Math.exp(-8 * dt));
      if (
        Math.abs(lookNow.current.x - publishedLook.current.x) > 0.02 ||
        Math.abs(lookNow.current.y - publishedLook.current.y) > 0.02
      ) {
        publishedLook.current = { ...lookNow.current };
        setLook(lookNow.current.x, lookNow.current.y);
      }
      setParticles((prev) => {
        if (prev.length === 0) return prev;
        return prev
          .map((p) => ({
            ...p,
            x: p.x + p.vx * dt,
            y: p.y + p.vy * dt,
            vy: p.vy + 40 * dt,
            life: p.life - dt,
          }))
          .filter((p) => p.life > 0);
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [setLook]);

  useEffect(() => {
    const tick = () => {
      const m = usePetStore.getState().mood;
      if (m === "idle" || m === "soothe" || m === "curious") {
        setBlinking(true);
        window.setTimeout(() => setBlinking(false), 140);
      }
      timers.current.blink = window.setTimeout(tick, 2800 + Math.random() * 2600);
    };
    timers.current.blink = window.setTimeout(tick, 1800);
    return () => window.clearTimeout(timers.current.blink);
  }, []);

  useEffect(() => {
    const wander = () => {
      const m = usePetStore.getState().mood;
      if (m === "idle" && !usePetStore.getState().held) {
        lookTarget.current = {
          x: (Math.random() - 0.5) * 1.2,
          y: (Math.random() - 0.5) * 0.8,
        };
      }
    };
    const id = window.setInterval(wander, 3200);
    return () => window.clearInterval(id);
  }, []);

  const lookAtPoint = (clientX: number, clientY: number) => {
    const face = sceneRef.current?.querySelector(".nubo-oled") as HTMLElement | null;
    if (!face) return;
    const r = face.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const nx = Math.max(-1, Math.min(1, (clientX - cx) / (window.innerWidth * 0.35)));
    const ny = Math.max(-1, Math.min(1, (clientY - cy) / (window.innerHeight * 0.35)));
    lookTarget.current = { x: nx, y: ny };
  };

  const applyShake = useCallback(() => {
    const now = performance.now();
    if (now - lastShake.current < SHAKE_COOLDOWN) return;
    lastShake.current = now;
    interruptSleepTimer();
    const next = pick(SHAKE_MOODS);
    setFood(null);
    goMood(next, 3200);
    buzz([18, 40, 30]);
    setHeld(false);
    setHold(null);
  }, [goMood, setFood, setHeld]);

  const onMotion = useCallback(
    (e: DeviceMotionEvent) => {
      const acc = e.accelerationIncludingGravity;
      if (!acc) return;
      const t = performance.now();
      const cur = { x: acc.x ?? 0, y: acc.y ?? 0, z: acc.z ?? 0, t };
      const prev = accPrev.current;
      accPrev.current = cur;
      if (!prev || t - prev.t < 50) return;
      const speed =
        Math.abs(cur.x - prev.x) + Math.abs(cur.y - prev.y) + Math.abs(cur.z - prev.z);
      if (speed > 22) applyShake();
    },
    [applyShake],
  );

  const enableMotion = useCallback(async () => {
    try {
      const DM = window.DeviceMotionEvent as unknown as {
        requestPermission?: () => Promise<string>;
      };
      if (typeof DM.requestPermission === "function") {
        const res = await DM.requestPermission();
        if (res !== "granted") return;
      }
      window.removeEventListener("devicemotion", onMotion);
      window.addEventListener("devicemotion", onMotion);
      setMotionReady(true);
    } catch {
      window.removeEventListener("devicemotion", onMotion);
      window.addEventListener("devicemotion", onMotion);
      setMotionReady(true);
    }
  }, [onMotion]);

  useEffect(() => {
    return () => {
      window.removeEventListener("devicemotion", onMotion);
      window.clearTimeout(timers.current.mood);
      window.clearTimeout(timers.current.sleep);
      window.clearTimeout(timers.current.blink);
    };
  }, [onMotion]);

  const petHead = () => {
    interruptSleepTimer();
    setPokeCount(0);
    pokeRef.current = 0;
    setFood(null);
    goMood("soothe", SOOTHE_HOLD_MS);
    scheduleSleep();
    buzz(12);
  };

  const pokeBody = () => {
    interruptSleepTimer();
    const n = pokeRef.current + 1;
    pokeRef.current = n;
    setPokeCount(n);
    setFood(null);
    if (n >= 10) {
      goMood("angry");
      buzz([30, 40, 40, 40, 50]);
    } else {
      goMood("startle", 1100);
      buzz(24);
    }
  };

  const eatMouth = () => {
    interruptSleepTimer();
    const food = pick(FOODS);
    setFood(food);
    goMood("eat", 2800);
    buzz(10);
  };

  const happyForehead = () => {
    interruptSleepTimer();
    setFood(null);
    goMood("happy", 2600);
    buzz([10, 20, 10]);
  };

  const curiousAt = (x: number, y: number) => {
    interruptSleepTimer();
    lookAtPoint(x, y);
    setFood(null);
    goMood("curious", 1800);
  };

  const handleTap = (zone: HitZone, x: number, y: number) => {
    if (zone === "scene") {
      curiousAt(x, y);
      return;
    }
    if (zone === "mouth") {
      eatMouth();
      return;
    }
    if (zone === "body") {
      pokeBody();
      return;
    }
    if (zone === "forehead") {
      const now = performance.now();
      if (now - lastForehead.current < 420) {
        lastForehead.current = 0;
        happyForehead();
        return;
      }
      lastForehead.current = now;
      petHead();
      return;
    }
    petHead();
  };

  const onZonePointerDown = (zone: HitZone, e: ReactPointerEvent) => {
    e.stopPropagation();
    e.preventDefault();
    unlockAudio();
    void enableMotion();
    const target = e.currentTarget as HTMLElement;
    target.setPointerCapture?.(e.pointerId);
    drag.current = {
      active: true,
      pointerId: e.pointerId,
      zone,
      sx: e.clientX,
      sy: e.clientY,
      x: e.clientX,
      y: e.clientY,
      moved: false,
      samples: [{ t: performance.now(), x: e.clientX, y: e.clientY }],
    };
  };

  const onScenePointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest("[data-zone]")) return;
    if ((e.target as HTMLElement).closest("button, input, [role='dialog']")) return;
    unlockAudio();
    void enableMotion();
    drag.current = {
      active: true,
      pointerId: e.pointerId,
      zone: "scene",
      sx: e.clientX,
      sy: e.clientY,
      x: e.clientX,
      y: e.clientY,
      moved: false,
      samples: [],
    };
  };

  const onPointerMove = (e: ReactPointerEvent) => {
    const d = drag.current;
    if (!d || !d.active || d.pointerId !== e.pointerId) return;
    d.x = e.clientX;
    d.y = e.clientY;
    const dist = Math.hypot(d.x - d.sx, d.y - d.sy);
    const lift = d.sy - d.y;
    if (d.zone !== "scene" && (lift > 42 || dist > 64)) {
      d.moved = true;
      if (!held) setHeld(true);
      const dx = d.x - d.sx;
      const dy = d.y - d.sy;
      setHold({ x: dx, y: dy, rot: Math.max(-18, Math.min(18, dx * 0.08)) });
      const now = performance.now();
      d.samples.push({ t: now, x: d.x, y: d.y });
      if (d.samples.length > 12) d.samples.shift();
      const recent = d.samples.filter((s) => now - s.t < 320);
      if (recent.length >= 6) {
        let flips = 0;
        for (let i = 2; i < recent.length; i++) {
          const a = recent[i]!;
          const b = recent[i - 1]!;
          const c = recent[i - 2]!;
          const v1x = b.x - c.x;
          const v2x = a.x - b.x;
          if (v1x * v2x < 0 && Math.abs(v1x) + Math.abs(v2x) > 18) flips += 1;
        }
        const travel = recent.reduce((sum, p, i) => {
          if (i === 0) return 0;
          return sum + Math.hypot(p.x - recent[i - 1]!.x, p.y - recent[i - 1]!.y);
        }, 0);
        if (flips >= 3 || travel > 280) {
          drag.current = null;
          applyShake();
        }
      }
    }
    if (d.zone === "scene") lookAtPoint(e.clientX, e.clientY);
  };

  const onPointerUp = (e: ReactPointerEvent) => {
    const d = drag.current;
    if (!d || d.pointerId !== e.pointerId) return;
    const moved = d.moved;
    const zone = d.zone;
    const x = e.clientX;
    const y = e.clientY;
    const lift = d.sy - d.y;
    drag.current = null;
    if (held || moved) {
      setHeld(false);
      setHold(null);
      if (lift > 48 || moved) applyShake();
      return;
    }
    handleTap(zone, x, y);
  };

  const onPointerCancel = () => {
    drag.current = null;
    setHeld(false);
    setHold(null);
  };

  return (
    <div className="nubo-app" data-theme={theme} data-mood={mood}>
      <div
        ref={sceneRef}
        className="nubo-scene"
        onPointerDown={onScenePointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerCancel}
      >
        <div className="nubo-glow" />
        <div className="nubo-desk" />
        <FxLayer particles={particles} mood={mood} />
        <Robot blinking={blinking} hold={hold} onZonePointerDown={onZonePointerDown} />
      </div>

      <header className="nubo-top">
        <div className="nubo-brand">
          <span className="nubo-brand-kicker">Desk pal</span>
          <span className="nubo-brand-name">{name}</span>
        </div>
        <div className="nubo-top-actions">
          <button
            type="button"
            className="nubo-icon-btn"
            aria-label="玩法"
            onClick={() => setHelpOpen(!helpOpen)}
          >
            <HelpCircle size={20} strokeWidth={2} />
          </button>
          <SettingsSheet motionReady={motionReady} onEnableMotion={() => void enableMotion()} />
        </div>
      </header>

      {helpOpen ? (
        <aside className="nubo-help" aria-label="玩法">
          <div className="nubo-help-head">
            <p>怎麼跟他玩</p>
            <button
              type="button"
              className="nubo-icon-btn nubo-icon-btn-ghost"
              aria-label="關閉玩法"
              onClick={() => setHelpOpen(false)}
            >
              <X size={18} />
            </button>
          </div>
          <ul>
            {HELP.map((item) => (
              <li key={item.title}>
                <strong>{item.title}</strong>
                <span>{item.text}</span>
              </li>
            ))}
          </ul>
        </aside>
      ) : null}

      {settingsOpen ? null : (
        <p className="nubo-hint">摸頭 · 點嘴巴 · 點身體 · 點畫面 · 搖一搖</p>
      )}
    </div>
  );
}
