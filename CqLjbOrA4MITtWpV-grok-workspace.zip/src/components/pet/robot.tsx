import type { CSSProperties, PointerEvent as ReactPointerEvent } from "react";
import { EYE_COLOR, MOOD_LABEL, type HitZone, type Mood } from "@/lib/pet-types";
import { usePetStore } from "@/lib/pet-store";
import { PixelFace } from "./pixel-face";
import { FoodProp } from "./food-prop";

type Hold = {
  x: number;
  y: number;
  rot: number;
};

type Props = {
  blinking: boolean;
  hold: Hold | null;
  onZonePointerDown: (zone: HitZone, e: ReactPointerEvent) => void;
};

export function Robot({ blinking, hold, onZonePointerDown }: Props) {
  const mood = usePetStore((s) => s.mood);
  const name = usePetStore((s) => s.name);
  const theme = usePetStore((s) => s.theme);
  const lookX = usePetStore((s) => s.lookX);
  const lookY = usePetStore((s) => s.lookY);
  const food = usePetStore((s) => s.food);
  const held = usePetStore((s) => s.held);
  const animNonce = usePetStore((s) => s.animNonce);

  const style: CSSProperties | undefined = hold
    ? {
        transform: `translate(${hold.x}px, ${hold.y}px) rotate(${hold.rot}deg)`,
        transition: "none",
      }
    : undefined;

  return (
    <div className="nubo-stage">
      <div
        className="nubo-shadow"
        data-held={held ? "1" : "0"}
        data-mood={mood}
        style={
          hold
            ? {
                transform: `translateX(${hold.x * 0.4}px) scale(${0.72 + Math.min(0.2, Math.abs(hold.y) / 400)})`,
              }
            : undefined
        }
      />
      <div
        className="nubo-robot"
        data-mood={mood}
        data-held={held ? "1" : "0"}
        data-nonce={animNonce}
        style={style}
      >
        <Arm side="left" mood={mood} />
        <Arm side="right" mood={mood} />
        <button
          type="button"
          className="nubo-torso"
          data-zone="body"
          aria-label="點身體"
          onPointerDown={(e) => onZonePointerDown("body", e)}
        >
          <span className="nubo-belly" />
          <span className="nubo-plate">{name || "robot"}</span>
        </button>
        <div className="nubo-head">
          <span className="nubo-cap" aria-hidden="true" />
          <button
            type="button"
            className="nubo-head-hit"
            data-zone="head"
            aria-label="摸頭"
            onPointerDown={(e) => onZonePointerDown("head", e)}
          />
          <button
            type="button"
            className="nubo-forehead"
            data-zone="forehead"
            aria-label="連點額頭"
            onPointerDown={(e) => onZonePointerDown("forehead", e)}
          />
          <div className="nubo-oled">
            <PixelFace
              mood={mood}
              lookX={lookX}
              lookY={lookY}
              eyeColor={EYE_COLOR[theme]}
              blinking={blinking}
            />
          </div>
          <button
            type="button"
            className="nubo-mouth"
            data-zone="mouth"
            aria-label="點嘴巴"
            onPointerDown={(e) => onZonePointerDown("mouth", e)}
          />
          {food ? <FoodProp kind={food} /> : null}
        </div>
      </div>
      <p className="nubo-mood-label">{MOOD_LABEL[mood]}</p>
    </div>
  );
}

function Arm({ side, mood }: { side: "left" | "right"; mood: Mood }) {
  return <span className="nubo-arm" data-side={side} data-mood={mood} aria-hidden="true" />;
}
