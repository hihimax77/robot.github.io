import { useEffect, useRef } from "react";
import type { Mood } from "@/lib/pet-types";

type Props = {
  mood: Mood;
  lookX: number;
  lookY: number;
  eyeColor: string;
  blinking: boolean;
};

const W = 128;
const H = 64;

function oval(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  color: string,
) {
  const rxn = Math.max(1, Math.round(rx));
  const ryn = Math.max(1, Math.round(ry));
  ctx.fillStyle = color;
  for (let y = -ryn; y <= ryn; y++) {
    const t = 1 - (y * y) / (ryn * ryn);
    if (t < 0) continue;
    const xw = Math.round(Math.sqrt(t) * rxn);
    ctx.fillRect(Math.round(cx) - xw, Math.round(cy) + y, xw * 2 + 1, 1);
  }
}

function stamp(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  w: number,
  color: string,
) {
  for (let i = 0; i <= 16; i++) {
    const t = i / 16;
    const u = 1 - t;
    const x = u * u * x0 + 2 * u * t * x1 + t * t * x2;
    const y = u * u * y0 + 2 * u * t * y1 + t * t * y2;
    oval(ctx, x, y, w, w * 0.9, color);
  }
}

function thickLine(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  r: number,
  color: string,
) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const n = Math.max(8, Math.round(Math.hypot(dx, dy)));
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    oval(ctx, x0 + dx * t, y0 + dy * t, r, r, color);
  }
}

function spark(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, color: string) {
  thickLine(ctx, x - s, y, x + s, y, 1.2, color);
  thickLine(ctx, x, y - s, x, y + s, 1.2, color);
}

export function PixelFace({ mood, lookX, lookY, eyeColor, blinking }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const t0 = useRef(performance.now());

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    t0.current = performance.now();
    let raf = 0;
    const loop = (now: number) => {
      const t = (now - t0.current) / 1000;
      drawFace(ctx, {
        mood,
        lookX,
        lookY,
        eyeColor,
        blinking,
        t,
      });
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [mood, lookX, lookY, eyeColor, blinking]);

  return (
    <canvas
      ref={ref}
      width={W}
      height={H}
      className="nubo-oled-canvas"
      aria-hidden="true"
    />
  );
}

type Draw = {
  mood: Mood;
  lookX: number;
  lookY: number;
  eyeColor: string;
  blinking: boolean;
  t: number;
};

function drawFace(ctx: CanvasRenderingContext2D, d: Draw) {
  ctx.fillStyle = "#07080a";
  ctx.fillRect(0, 0, W, H);

  const color = d.eyeColor;
  const dim = mix(color, "#07080a", 0.38);
  const lx = 38 + d.lookX * 8;
  const rx = 90 + d.lookX * 8;
  const ey = 30 + d.lookY * 6;

  if (d.mood === "boot") {
    const p = Math.min(1, d.t / 0.7);
    oval(ctx, 64, 32, 22 * p + 8, 2.2, color);
    if (p > 0.45) {
      const open = (p - 0.45) / 0.55;
      oval(ctx, lx, ey, 16, 2 + 14 * open, color);
      oval(ctx, rx, ey, 16, 2 + 14 * open, color);
    }
    return;
  }

  if (d.blinking && (d.mood === "idle" || d.mood === "curious")) {
    oval(ctx, lx, ey, 16, 2.2, color);
    oval(ctx, rx, ey, 16, 2.2, color);
    return;
  }

  switch (d.mood) {
    case "idle":
      oval(ctx, lx, ey, 16, 15, color);
      oval(ctx, rx, ey, 16, 15, color);
      oval(ctx, lx - 5, ey - 5, 4, 3.5, mix(color, "#ffffff", 0.45));
      oval(ctx, rx - 5, ey - 5, 4, 3.5, mix(color, "#ffffff", 0.45));
      break;
    case "soothe":
      stamp(ctx, lx - 16, ey + 6, lx, ey - 11, lx + 16, ey + 6, 2.6, color);
      stamp(ctx, rx - 16, ey + 6, rx, ey - 11, rx + 16, ey + 6, 2.6, color);
      oval(ctx, 22, 46, 8, 4, "#ff8fab");
      oval(ctx, 106, 46, 8, 4, "#ff8fab");
      break;
    case "sleep": {
      const wiggle = Math.sin(d.t * 1.4) * 0.8;
      oval(ctx, lx, ey + 3 + wiggle, 17, 2.2, color);
      oval(ctx, rx, ey + 3 - wiggle, 17, 2.2, color);
      break;
    }
    case "dizzy": {
      const a = d.t * 6;
      oval(ctx, lx + Math.cos(a) * 3, ey + Math.sin(a) * 2, 14, 14, color);
      oval(ctx, lx + Math.cos(a + 1.2) * 5, ey + Math.sin(a + 1.2) * 4, 5, 5, dim);
      oval(ctx, rx + Math.cos(a + 0.7) * 3, ey + Math.sin(a + 0.7) * 2, 14, 14, color);
      oval(ctx, rx + Math.cos(a + 2) * 5, ey + Math.sin(a + 2) * 4, 5, 5, dim);
      spark(ctx, 14, 12, 5 + Math.sin(d.t * 8), color);
      spark(ctx, 114, 16, 4 + Math.cos(d.t * 7), color);
      break;
    }
    case "faint":
      thickLine(ctx, lx - 12, ey - 11, lx + 12, ey + 11, 2.6, color);
      thickLine(ctx, lx + 12, ey - 11, lx - 12, ey + 11, 2.6, color);
      thickLine(ctx, rx - 12, ey - 11, rx + 12, ey + 11, 2.6, color);
      thickLine(ctx, rx + 12, ey - 11, rx - 12, ey + 11, 2.6, color);
      oval(ctx, 64, 52, 8, 3.5, color);
      break;
    case "cry": {
      oval(ctx, lx, ey, 13, 16, color);
      oval(ctx, rx, ey, 13, 16, color);
      oval(ctx, lx, ey - 2, 4, 4, "#07080a");
      oval(ctx, rx, ey - 2, 4, 4, "#07080a");
      stamp(ctx, 50, 48, 64, 56, 78, 48, 1.8, color);
      const drop = ((d.t * 28) % 22) + 40;
      oval(ctx, lx, drop, 2.6, 4, color);
      oval(ctx, rx, drop + 4, 2.6, 4, color);
      break;
    }
    case "eat": {
      stamp(ctx, lx - 15, ey + 4, lx, ey - 10, lx + 15, ey + 4, 2.5, color);
      stamp(ctx, rx - 15, ey + 4, rx, ey - 10, rx + 15, ey + 4, 2.5, color);
      const chew = 6 + Math.abs(Math.sin(d.t * 10)) * 6;
      oval(ctx, 64, 50, 11, chew, color);
      oval(ctx, 64, 50, 6, Math.max(1, chew - 3), "#07080a");
      break;
    }
    case "startle":
      oval(ctx, lx, ey, 18, 18, color);
      oval(ctx, rx, ey, 18, 18, color);
      oval(ctx, lx + d.lookX * 4, ey + d.lookY * 4, 5, 6, "#07080a");
      oval(ctx, rx + d.lookX * 4, ey + d.lookY * 4, 5, 6, "#07080a");
      break;
    case "angry":
      thickLine(ctx, lx - 16, ey - 12, lx + 14, ey - 2, 2.8, color);
      thickLine(ctx, rx + 16, ey - 12, rx - 14, ey - 2, 2.8, color);
      oval(ctx, lx, ey + 6, 12, 9, color);
      oval(ctx, rx, ey + 6, 12, 9, color);
      oval(ctx, lx, ey + 7, 4, 4, "#07080a");
      oval(ctx, rx, ey + 7, 4, 4, "#07080a");
      thickLine(ctx, 50, 52, 78, 52, 1.8, color);
      break;
    case "curious": {
      oval(ctx, lx, ey, 12, 17, color);
      oval(ctx, rx, ey, 17, 13, color);
      oval(ctx, lx + d.lookX * 4, ey + d.lookY * 5, 4, 5, "#07080a");
      oval(ctx, rx + d.lookX * 5, ey + d.lookY * 4, 4.5, 4.5, "#07080a");
      oval(ctx, lx - 3, ey - 5, 3, 2.5, mix(color, "#ffffff", 0.4));
      break;
    }
    case "happy":
      stamp(ctx, lx - 17, ey + 7, lx, ey - 13, lx + 17, ey + 7, 2.8, color);
      stamp(ctx, rx - 17, ey + 7, rx, ey - 13, rx + 17, ey + 7, 2.8, color);
      stamp(ctx, 48, 46, 64, 58, 80, 46, 2, color);
      spark(ctx, 12, 12, 6 + Math.sin(d.t * 8), color);
      spark(ctx, 116, 16, 5 + Math.cos(d.t * 6), color);
      oval(ctx, 20, 46, 8, 4, "#ff8fab");
      oval(ctx, 108, 46, 8, 4, "#ff8fab");
      break;
    default:
      oval(ctx, lx, ey, 16, 15, color);
      oval(ctx, rx, ey, 16, 15, color);
  }
}

function mix(hex: string, other: string, t: number) {
  const a = parseHex(hex);
  const b = parseHex(other);
  const m = (i: number) => Math.round(a[i]! * (1 - t) + b[i]! * t);
  return `rgb(${m(0)} ${m(1)} ${m(2)})`;
}

function parseHex(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  if (h.length !== 6) return [126, 232, 234];
  return [
    Number.parseInt(h.slice(0, 2), 16),
    Number.parseInt(h.slice(2, 4), 16),
    Number.parseInt(h.slice(4, 6), 16),
  ];
}
