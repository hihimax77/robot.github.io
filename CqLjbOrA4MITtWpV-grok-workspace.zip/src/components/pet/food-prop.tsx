import type { FoodKind } from "@/lib/pet-types";

export function FoodProp({ kind }: { kind: FoodKind }) {
  return (
    <div className="nubo-food" data-kind={kind} aria-hidden="true">
      {kind === "lollipop" ? <Lollipop /> : kind === "burger" ? <Burger /> : <Sushi />}
    </div>
  );
}

function Lollipop() {
  return (
    <svg viewBox="0 0 64 96" className="nubo-food-svg">
      <rect x="30" y="40" width="5" height="48" rx="2" fill="#e8d5b0" />
      <circle cx="32" cy="28" r="22" fill="#ff6b8a" />
      <path
        d="M32 10c10 0 18 8 18 18 0 4-1 7-3 10"
        fill="none"
        stroke="#ffe3ea"
        strokeWidth="5"
        strokeLinecap="round"
      />
      <circle cx="24" cy="20" r="5" fill="rgba(255,255,255,0.45)" />
    </svg>
  );
}

function Burger() {
  return (
    <svg viewBox="0 0 72 64" className="nubo-food-svg">
      <ellipse cx="36" cy="18" rx="28" ry="12" fill="#e2a054" />
      <rect x="8" y="18" width="56" height="8" fill="#e2a054" />
      <rect x="10" y="26" width="52" height="6" rx="2" fill="#6dbd5b" />
      <rect x="9" y="32" width="54" height="10" rx="3" fill="#7a3e24" />
      <rect x="11" y="42" width="50" height="6" rx="2" fill="#f1d36b" />
      <ellipse cx="36" cy="52" rx="28" ry="9" fill="#c9843a" />
      <circle cx="22" cy="16" r="2.2" fill="#f4f0e6" />
      <circle cx="40" cy="14" r="1.8" fill="#f4f0e6" />
    </svg>
  );
}

function Sushi() {
  return (
    <svg viewBox="0 0 80 48" className="nubo-food-svg">
      <ellipse cx="40" cy="28" rx="32" ry="14" fill="#1c1c20" />
      <ellipse cx="40" cy="24" rx="28" ry="11" fill="#f4efe6" />
      <ellipse cx="40" cy="18" rx="26" ry="9" fill="#e07070" />
      <path d="M18 18c8 4 36 4 44 0" fill="none" stroke="#f4efe6" strokeWidth="2" />
      <rect x="36" y="8" width="8" height="28" fill="#1c1c20" />
    </svg>
  );
}
