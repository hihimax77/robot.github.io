import { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Check, Menu, X } from "lucide-react";
import { THEMES } from "@/lib/pet-types";
import { usePetStore } from "@/lib/pet-store";

type Props = {
  motionReady: boolean;
  onEnableMotion: () => void;
};

export function SettingsSheet({ motionReady, onEnableMotion }: Props) {
  const open = usePetStore((s) => s.settingsOpen);
  const setOpen = usePetStore((s) => s.setSettingsOpen);
  const name = usePetStore((s) => s.name);
  const setName = usePetStore((s) => s.setName);
  const theme = usePetStore((s) => s.theme);
  const setTheme = usePetStore((s) => s.setTheme);
  const [draft, setDraft] = useState(name);

  useEffect(() => {
    if (open) setDraft(name);
  }, [open, name]);

  function commitName() {
    setName(draft.trim() ? draft : "robot");
  }

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <button type="button" className="nubo-icon-btn" aria-label="開啟設定">
          <Menu size={22} strokeWidth={2} />
        </button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="nubo-overlay" />
        <Dialog.Content className="nubo-sheet" aria-describedby={undefined}>
          <div className="nubo-sheet-head">
            <Dialog.Title className="nubo-sheet-title">設定</Dialog.Title>
            <Dialog.Close asChild>
              <button type="button" className="nubo-icon-btn nubo-icon-btn-ghost" aria-label="關閉設定">
                <X size={20} strokeWidth={2} />
              </button>
            </Dialog.Close>
          </div>

          <label className="nubo-field">
            <span className="nubo-field-label">姓名</span>
            <input
              className="nubo-input"
              value={draft}
              maxLength={16}
              placeholder="robot"
              onChange={(e) => setDraft(e.target.value)}
              onBlur={commitName}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  commitName();
                  (e.target as HTMLInputElement).blur();
                }
              }}
            />
            <span className="nubo-field-hint">沒填的話會叫 robot</span>
          </label>

          <fieldset className="nubo-field">
            <legend className="nubo-field-label">色系</legend>
            <div className="nubo-swatches">
              {THEMES.map((item) => {
                const selected = theme === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    className="nubo-swatch"
                    data-selected={selected ? "1" : "0"}
                    data-theme-id={item.id}
                    onClick={() => setTheme(item.id)}
                    aria-pressed={selected}
                  >
                    <span className="nubo-swatch-dot" />
                    <span className="nubo-swatch-name">{item.label}</span>
                    {selected ? <Check size={16} strokeWidth={2.4} /> : <span className="nubo-swatch-spacer" />}
                  </button>
                );
              })}
            </div>
          </fieldset>

          <div className="nubo-field">
            <span className="nubo-field-label">搖晃感應</span>
            {motionReady ? (
              <p className="nubo-field-hint">已開啟。搖晃手機會讓他暈眩、昏倒或哭哭。</p>
            ) : (
              <button type="button" className="nubo-btn" onClick={onEnableMotion}>
                允許搖晃感應
              </button>
            )}
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
