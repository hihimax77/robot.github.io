import { Heart } from "lucide-react";
import type { Mood } from "@/lib/pet-types";

export type Particle = {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  kind: "heart" | "zzz" | "spark";
};

export function FxLayer({ particles, mood }: { particles: Particle[]; mood: Mood }) {
  return (
    <div className="nubo-fx" aria-hidden="true">
      {particles.map((p) => {
        const t = 1 - p.life / p.max;
        const style = {
          left: `${p.x}px`,
          top: `${p.y}px`,
          opacity: t,
          transform: `translate(-50%, -50%) scale(${0.7 + t * 0.5})`,
        };
        if (p.kind === "heart") {
          return (
            <span key={p.id} className="nubo-part nubo-part-heart" style={style}>
              <Heart size={18} fill="currentColor" strokeWidth={0} />
            </span>
          );
        }
        if (p.kind === "zzz") {
          return (
            <span key={p.id} className="nubo-part nubo-part-z" style={style}>
              z
            </span>
          );
        }
        return (
          <span key={p.id} className="nubo-part nubo-part-spark" style={style}>
            +
          </span>
        );
      })}
      {mood === "sleep" ? <span className="nubo-snore">z</span> : null}
    </div>
  );
}
