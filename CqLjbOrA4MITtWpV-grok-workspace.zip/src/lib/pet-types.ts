export type ThemeId = "black" | "pink" | "sunset" | "teal";
export type Mood =
  | "boot"
  | "idle"
  | "soothe"
  | "sleep"
  | "dizzy"
  | "faint"
  | "cry"
  | "eat"
  | "startle"
  | "angry"
  | "curious"
  | "happy";
export type FoodKind = "lollipop" | "burger" | "sushi";
export type HitZone = "head" | "forehead" | "mouth" | "body" | "scene";

export const THEMES: {
  id: ThemeId;
  label: string;
  swatch: string;
}[] = [
  { id: "black", label: "黑", swatch: "#1a1b20" },
  { id: "pink", label: "粉紅", swatch: "#ffc0cb" },
  { id: "sunset", label: "夕陽橙", swatch: "#f1b04c" },
  { id: "teal", label: "土耳其藍", swatch: "#40e0d0" },
];

export const MOOD_LABEL: Record<Mood, string> = {
  boot: "開機中",
  idle: "放空",
  soothe: "療癒中",
  sleep: "睡著了",
  dizzy: "暈乎乎",
  faint: "昏倒了",
  cry: "嗚嗚",
  eat: "好好吃",
  startle: "嚇到了",
  angry: "生氣氣",
  curious: "那是什麼",
  happy: "驚喜",
};

export const EYE_COLOR: Record<ThemeId, string> = {
  black: "#7ee8ea",
  pink: "#ff8fab",
  sunset: "#ffe0a3",
  teal: "#e8fffc",
};

export const SHAKE_MOODS: Mood[] = ["dizzy", "faint", "cry"];
export const FOODS: FoodKind[] = ["lollipop", "burger", "sushi"];

export function pick<T>(list: readonly T[]): T {
  return list[Math.floor(Math.random() * list.length)]!;
}
