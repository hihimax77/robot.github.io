type Chirp = {
  freq: number;
  dur: number;
  type?: OscillatorType;
  gain?: number;
  slide?: number;
  delay?: number;
};

let ctx: AudioContext | null = null;
let unlocked = false;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  return ctx;
}

export function unlockAudio() {
  const c = getCtx();
  if (!c) return;
  if (c.state === "suspended") void c.resume();
  unlocked = true;
}

function playOne(c: AudioContext, chirp: Chirp, at: number) {
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = chirp.type ?? "sine";
  osc.frequency.setValueAtTime(chirp.freq, at);
  if (chirp.slide) {
    osc.frequency.exponentialRampToValueAtTime(
      Math.max(40, chirp.freq * chirp.slide),
      at + chirp.dur,
    );
  }
  const g = chirp.gain ?? 0.07;
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.exponentialRampToValueAtTime(g, at + 0.018);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + chirp.dur);
  osc.connect(gain);
  gain.connect(c.destination);
  osc.start(at);
  osc.stop(at + chirp.dur + 0.02);
}

function play(notes: Chirp[]) {
  const c = getCtx();
  if (!c || !unlocked) return;
  if (c.state === "suspended") void c.resume();
  const t0 = c.currentTime;
  for (const n of notes) playOne(c, n, t0 + (n.delay ?? 0));
}

export const petSfx = {
  boot: () =>
    play([
      { freq: 440, dur: 0.09, delay: 0 },
      { freq: 660, dur: 0.12, delay: 0.1 },
      { freq: 880, dur: 0.16, delay: 0.22, slide: 1.1 },
    ]),
  soothe: () =>
    play([
      { freq: 523, dur: 0.14, gain: 0.05 },
      { freq: 659, dur: 0.18, delay: 0.12, gain: 0.05 },
      { freq: 784, dur: 0.22, delay: 0.26, gain: 0.04 },
    ]),
  startle: () =>
    play([{ freq: 980, dur: 0.08, type: "square", gain: 0.04, slide: 1.4 }]),
  angry: () =>
    play([
      { freq: 140, dur: 0.16, type: "sawtooth", gain: 0.04 },
      { freq: 110, dur: 0.2, type: "sawtooth", gain: 0.04, delay: 0.14 },
    ]),
  eat: () =>
    play([
      { freq: 180, dur: 0.07, type: "triangle", gain: 0.06 },
      { freq: 160, dur: 0.07, type: "triangle", gain: 0.05, delay: 0.12 },
      { freq: 200, dur: 0.08, type: "triangle", gain: 0.05, delay: 0.24 },
    ]),
  happy: () =>
    play([
      { freq: 523, dur: 0.1 },
      { freq: 659, dur: 0.1, delay: 0.1 },
      { freq: 784, dur: 0.12, delay: 0.2 },
      { freq: 1046, dur: 0.18, delay: 0.32, gain: 0.05 },
    ]),
  cry: () =>
    play([
      { freq: 420, dur: 0.22, slide: 0.7, gain: 0.05 },
      { freq: 360, dur: 0.28, slide: 0.65, gain: 0.04, delay: 0.24 },
    ]),
  dizzy: () =>
    play([
      { freq: 500, dur: 0.18, slide: 0.6, type: "triangle", gain: 0.05 },
      { freq: 700, dur: 0.18, slide: 0.55, type: "triangle", gain: 0.04, delay: 0.16 },
    ]),
  faint: () =>
    play([{ freq: 240, dur: 0.4, slide: 0.4, type: "sine", gain: 0.05 }]),
  curious: () =>
    play([{ freq: 480, dur: 0.16, slide: 1.6, gain: 0.045 }]),
  sleep: () =>
    play([{ freq: 220, dur: 0.35, slide: 0.7, gain: 0.03 }]),
};

export function playMoodSfx(mood: string) {
  const map: Record<string, () => void> = {
    soothe: petSfx.soothe,
    startle: petSfx.startle,
    angry: petSfx.angry,
    eat: petSfx.eat,
    happy: petSfx.happy,
    cry: petSfx.cry,
    dizzy: petSfx.dizzy,
    faint: petSfx.faint,
    curious: petSfx.curious,
    sleep: petSfx.sleep,
    boot: petSfx.boot,
  };
  map[mood]?.();
}
