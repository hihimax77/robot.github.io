import { create } from "zustand";
import type { FoodKind, Mood, ThemeId } from "./pet-types";

const STORAGE_KEY = "nubo-settings-v1";

type Saved = { name: string; theme: ThemeId };

function readSaved(): Saved {
  if (typeof window === "undefined") return { name: "robot", theme: "black" };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { name: "robot", theme: "black" };
    const parsed = JSON.parse(raw) as Partial<Saved>;
    const name =
      typeof parsed.name === "string" && parsed.name.trim()
        ? parsed.name.trim().slice(0, 16)
        : "robot";
    const theme: ThemeId =
      parsed.theme === "pink" ||
      parsed.theme === "sunset" ||
      parsed.theme === "teal" ||
      parsed.theme === "black"
        ? parsed.theme
        : "black";
    return { name, theme };
  } catch {
    return { name: "robot", theme: "black" };
  }
}

function writeSaved(name: string, theme: ThemeId) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ name, theme }));
  } catch {
    /* ignore quota */
  }
}

export type PetState = {
  name: string;
  theme: ThemeId;
  mood: Mood;
  food: FoodKind | null;
  pokeCount: number;
  lookX: number;
  lookY: number;
  held: boolean;
  settingsOpen: boolean;
  helpOpen: boolean;
  animNonce: number;
  hydrated: boolean;
  hydrate: () => void;
  setName: (name: string) => void;
  setTheme: (theme: ThemeId) => void;
  setMood: (mood: Mood) => void;
  setFood: (food: FoodKind | null) => void;
  setPokeCount: (n: number) => void;
  setLook: (x: number, y: number) => void;
  setHeld: (held: boolean) => void;
  setSettingsOpen: (open: boolean) => void;
  setHelpOpen: (open: boolean) => void;
  bumpAnim: () => void;
};

export const usePetStore = create<PetState>((set, get) => ({
  name: "robot",
  theme: "black",
  mood: "boot",
  food: null,
  pokeCount: 0,
  lookX: 0,
  lookY: 0,
  held: false,
  settingsOpen: false,
  helpOpen: false,
  animNonce: 0,
  hydrated: false,
  hydrate: () => {
    if (get().hydrated) return;
    const saved = readSaved();
    set({ name: saved.name, theme: saved.theme, hydrated: true });
  },
  setName: (name) => {
    const next = name.trim() ? name.trim().slice(0, 16) : "robot";
    set({ name: next });
    writeSaved(next, get().theme);
  },
  setTheme: (theme) => {
    set({ theme });
    writeSaved(get().name, theme);
  },
  setMood: (mood) => set({ mood }),
  setFood: (food) => set({ food }),
  setPokeCount: (n) => set({ pokeCount: n }),
  setLook: (x, y) => set({ lookX: x, lookY: y }),
  setHeld: (held) => set({ held }),
  setSettingsOpen: (open) => set({ settingsOpen: open }),
  setHelpOpen: (open) => set({ helpOpen: open }),
  bumpAnim: () => set({ animNonce: get().animNonce + 1 }),
}));
