import { createFileRoute } from "@tanstack/react-router";
import { PetScene } from "@/components/pet/pet-scene";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <PetScene />;
}
